package cs2030.util;

import java.util.Comparator;
import java.util.PriorityQueue;

public class PQ<T extends Comparable<T>> implements Comparator<T> {

    private final PriorityQueue<T> queue;

    public PQ(Comparator<? super T> c) {
        this.queue = new PriorityQueue<T>(c);
    }

    public PQ(PQ<T> oldPQ) {
        this.queue = new PriorityQueue<T>(oldPQ.queue);
    }

    public PQ<T> add(T element) {
        PQ<T> newPQ = new PQ<T>(this);
        newPQ.queue.add(element);
        return newPQ;
    }

    @Override
    public int compare(T a, T b) {
        return a.compareTo(b);
    }

    public Pair<T,PQ<T>> poll() {
        PQ<T> newPQ = new PQ<T>(this);
        T value = newPQ.queue.poll();
        return Pair.<T,PQ<T>>of(value, newPQ);
    }

    public boolean isEmpty() {
        return queue.isEmpty();
    }

    @Override
    public String toString() {
        return queue.toString();
    }

}