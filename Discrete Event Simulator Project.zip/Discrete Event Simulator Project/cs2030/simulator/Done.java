package cs2030.simulator;


import java.util.Optional;

import cs2030.util.Pair;

public class Done extends Event {

    private final Server server;
        
    public Done(Customer cust, double eventTime, Server server) {
        super(cust, eventTime, "Done");
        this.server = server;
    }

    @Override
    public Server getServer() {
        return server;
    }

    @Override
    public Pair<Optional<Event>,Shop> execute(Shop shop) {
        return Pair.<Optional<Event>,Shop>of(Optional.<Event>empty(), shop);
    }

    @Override
    public String toString() {
        if (getServer().isHuman()) {
            return String.format("%.3f %s done serving by %s", getEventTime(),
            getCustomer().getCustomerID(), getServer());
        } else {
            return String.format("%.3f %s done serving by self-check %s", getEventTime(),
            getCustomer().getCustomerID(), getServer());
        }
    }
}
