package cs2030.simulator;

import java.util.List;
import java.util.Optional;
import java.util.function.Supplier;

import cs2030.util.ImList;
import cs2030.util.Pair;

public class Shop {
    private final ImList<Server> servers;

    public Shop(List<Server> list) {
        this.servers = ImList.<Server>of(list);
    }

    public Shop(int numOfServers, int queueSize) {
        ImList<Server> serverList = ImList.<Server>of();
        for (int i = 1; i < numOfServers + 1; i++) {
            serverList = serverList.add(new Server(i, queueSize, "Human"));
        }
        this.servers = serverList;
    }

    public Shop(int numOfServers, int queueSize, Supplier<Double> restTimeSupplier) {
        ImList<Server> serverList = ImList.<Server>of();
        for (int i = 1; i < numOfServers + 1; i++) {
            serverList = serverList.add(new Server(i, queueSize, restTimeSupplier, "Human"));
        }
        this.servers = serverList;
    }

    public Shop(int numOfServers, int numOfSelfChecks, int queueSize,
        Supplier<Double> restTimeSupplier) {
        ImList<Server> serverList = ImList.<Server>of();
        for (int i = 1; i < numOfServers + 1; i++) {
            serverList = serverList.add(new Server(i, queueSize, restTimeSupplier, "Human"));
        }
    
        for (int i = numOfServers + 1; i < numOfServers + numOfSelfChecks + 1; i++) {
            serverList = serverList.add(new Server(i, queueSize, "Self"));
        }
        this.servers = serverList;
    }

    public Shop(ImList<Server> updatedServerList) {
        this.servers = updatedServerList;
    }

    public Shop(Shop shop) {
        this.servers = shop.getServers();
    }

    public ImList<Server> getServers() {
        return servers;
    }

    public boolean isThereServer() { // check if there are any available servers to serve
        for (int i = 0; i < getServers().size(); i++) {
            Server currentServer = getServers().get(i);
            if (currentServer.canServe() && !currentServer.getRestStatus()) {
                return true;
            }
        }
        return false;
    }

    public boolean canQueue() { // check if any servers can take in queue
        for (int i = 0; i < getServers().size(); i++) {
            Server currentServer = getServers().get(i);
            if (currentServer.canWait()) {
                return true;
            }
        }
        return false;
    }

    public Server findServer() { // find particular server that is available to serve
        for (int i = 0; i < getServers().size(); i++) {
            Server currentServer = getServers().get(i);
            if (currentServer.canServe() && !currentServer.getRestStatus()) {
                return new Server(currentServer);
            }
        }
        return new Server(0, "Human");
    }

    public Server findQueue() { // find particular server to queue for
        for (int i = 0; i < getServers().size(); i++) {
            Server currentServer = getServers().get(i);
            if (currentServer.canWait()) {
                return new Server(currentServer);
            }
        }
        return new Server(0, "Human");
    }

    public Server findServerByID(int id) {
        Server server = getServers().get(id - 1);
        return new Server(server);
    }

    public Pair<Server, Shop> assignServer(Server s, Customer c, double eventTime) {
        if (s.isHuman()) {
            s = s.humanServe(c, eventTime); // server done at eventTime
        } else {
            s = s.selfServe(c, eventTime); // server done at eventTime
        }
        ImList<Server> updatedServersList = servers.set(s.getServerID() - 1, s);
        Shop updatedShop = new Shop(updatedServersList);
        return Pair.<Server, Shop>of(s, updatedShop);
    }

    public Pair<Server,Shop> assignQueue(Server s, Customer c) {
        if (s.isHuman()) {
            s = s.humanWait(c); // server done at eventTime
        } else {
            s = s.selfWait(c); // server done at eventTime
        }
        ImList<Server> updatedServersList = servers.set(s.getServerID() - 1, s);
        Shop updatedShop = new Shop(updatedServersList);
        return Pair.<Server,Shop>of(s, updatedShop);
    }

    public Pair<Server,Shop> removeServerServe(Server s) {
        if (s.isHuman()) {
            s = s.humanClearServe(); // server done at eventTime
        } else {
            s = s.selfClearServe(); // server done at eventTime
        }
        ImList<Server> updatedServersList = servers.set(s.getServerID() - 1, s);
        Shop updatedShop = new Shop(updatedServersList);
        return Pair.<Server,Shop>of(s, updatedShop);
    }

    public Pair<Server,Shop> removeServerWait(Server s) {
        if (s.isHuman()) {
            s = s.humanClearWait(); // server done at eventTime
        } else {
            s = s.selfClearWait(); // server done at eventTime
        }
        ImList<Server> updatedServersList = servers.set(s.getServerID() - 1, s);
        Shop updatedShop = new Shop(updatedServersList);
        return Pair.<Server,Shop>of(s, updatedShop);
    }

    public Pair<Server,Shop> removeServerRest(Server s) {
        Server updatedServer = s.clearRest();
        ImList<Server> updatedServersList = servers.set(updatedServer
            .getServerID() - 1, updatedServer);
        Shop updatedShop = new Shop(updatedServersList);
        return Pair.<Server,Shop>of(updatedServer, updatedShop);
    }

    public Shop updateServer(Server s) {
        ImList<Server> updatedServersList = servers.set(s.getServerID() - 1, s);
        Shop updatedShop = new Shop(updatedServersList);
        return updatedShop;
    }

    public Pair<Server,Shop> removeSelfCheckoutWait(Server s) {
        ImList<Server> serversList = getServers();
        for (int i = 0; i < getServers().size(); i++) {
            Server currentServer = getServers().get(i);
            if (currentServer.isSelfCheckout() && currentServer
                .getWaitingCustomersList().size() > 0) {
                currentServer = currentServer.selfClearWait();
                serversList = serversList.set(currentServer.getServerID() - 1, currentServer);
            }
        }
        Server updatedServer = s.selfClearWait();
        Shop updatedShop = new Shop(serversList);
        return Pair.<Server,Shop>of(updatedServer, updatedShop);
    }

    public Shop updateSelfCheckouts(ImList<Optional<Customer>> queue) {
        ImList<Server> serversList = getServers();
        for (int i = 0; i < getServers().size(); i++) {
            Server currentServer = getServers().get(i);
            if (currentServer.isSelfCheckout()) {
                currentServer = currentServer.selfSetWait(queue);
                serversList = serversList.set(currentServer.getServerID() - 1, currentServer);
            }
        }
        Shop updatedShop = new Shop(serversList);
        return updatedShop;
    }

    @Override
    public String toString() {
        return getServers().toString();
    }
}
