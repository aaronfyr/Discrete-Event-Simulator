package cs2030.simulator;

import java.util.Optional;

import cs2030.util.Pair;

public class Serve extends Event {
    private final Server server;
    
    public Serve(Customer cust, double eventTime, Server server) {
        super(cust, eventTime, "Serve");
        this.server = server;

    }

    public Server getServer() {
        return server;
    }

    @Override
    public Pair<Optional<Event>, Shop> execute(Shop shop) {
        Server currentServer = getServer();
        if (server.getRestStatus()) {
            currentServer = currentServer.clearRest();
        }
        

        if (currentServer.isSelfCheckout() && currentServer.getWaitingCustomersList().size() > 0) {
            Pair<Server,Shop> tempPair = shop.removeSelfCheckoutWait(currentServer);
            Server tempServer = tempPair.first();
            Shop tempShop = tempPair.second();
            Pair<Server,Shop> updatedPair = tempShop.assignServer(tempServer, getCustomer(),
                getEventTime() + getCustomer().getCustomerServiceTime());
            Server updatedServer = updatedPair.first();
            Shop updatedShop = updatedPair.second();
            return Pair.<Optional<Event>,Shop>of(Optional.<Event>of(new Done(getCustomer(),
                getEventTime() + getCustomer().getCustomerServiceTime(), updatedServer)),
                updatedShop);
        } else if (currentServer.isHuman() && currentServer.getWaitingCustomersList().size() > 0) {
            Pair<Server,Shop> tempPair = shop.removeServerWait(currentServer); 
            Server tempServer = tempPair.first();
            Shop tempShop = tempPair.second();
            Pair<Server,Shop> updatedPair = tempShop.assignServer(tempServer, getCustomer(),
                getEventTime() + getCustomer().getCustomerServiceTime());
            Server updatedServer = updatedPair.first();
            Shop updatedShop = updatedPair.second();
            return Pair.<Optional<Event>,Shop>of(Optional.<Event>of(new Done(getCustomer(),
            getEventTime() + getCustomer().getCustomerServiceTime(), updatedServer)), updatedShop);
        } else {
            Server tempServer = getServer();
            Shop tempShop = shop;
            Pair<Server,Shop> updatedPair = tempShop.assignServer(tempServer, getCustomer(),
                getEventTime() + getCustomer().getCustomerServiceTime());
            Server updatedServer = updatedPair.first();
            Shop updatedShop = updatedPair.second();
            return Pair.<Optional<Event>,Shop>of(Optional.<Event>of(new Done(getCustomer(),
            getEventTime() + getCustomer().getCustomerServiceTime(), updatedServer)), updatedShop);
        }
    }

    @Override
    public String toString() {
        if (getServer().isHuman()) {
            return String.format("%.3f %s serves by %s", getEventTime(),
            getCustomer().getCustomerID(), getServer());
        } else {
            return String.format("%.3f %s serves by self-check %s",
            getEventTime(), getCustomer().getCustomerID(), getServer());
        }
    }
}
