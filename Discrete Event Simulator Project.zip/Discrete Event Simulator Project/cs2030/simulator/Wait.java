package cs2030.simulator;

import java.util.Optional;

import cs2030.util.Pair;

public class Wait extends Event {

    private final Server server;
        
    public Wait(Customer cust, double eventTime, Server server) {
        super(cust, eventTime, "Wait");
        this.server = server;
    }
    
    @Override
    public Server getServer() {
        return server;
    }

    @Override
    public Pair<Optional<Event>, Shop> execute(Shop shop) {
        Pair<Server,Shop> updatedPair = shop.assignQueue(getServer(), getCustomer());
        Shop updatedShop = updatedPair.second();
        return Pair.<Optional<Event>,Shop>of(Optional.<Event>empty(), updatedShop);
    }

    @Override
    public String toString() {
        if (getServer().isHuman()) {
            return String.format("%.3f %s waits at %s",
                getEventTime(), getCustomer().getCustomerID(), getServer());
        } else {
            return String.format("%.3f %s waits at self-check %s",
                getEventTime(), getCustomer().getCustomerID(), getServer());
        }
    }
}
