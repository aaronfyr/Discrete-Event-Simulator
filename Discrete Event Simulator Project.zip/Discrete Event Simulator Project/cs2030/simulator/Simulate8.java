package cs2030.simulator;

import java.util.List;
import java.util.Optional;
import java.util.function.Supplier;

import cs2030.util.ImList;
import cs2030.util.PQ;
import cs2030.util.Pair;

public class Simulate8 {
    private final PQ<Event> eventPQ;
    private final Shop shop;

    public Simulate8(int servers, int selfChecks, List<Pair<Double, Supplier<Double>>> arrival,
        int queueSize, Supplier<Double> restTimeSupplier) {
        PQ<Event> pq = new PQ<Event>(new EventComparator());
        int numOfCust = arrival.size();
        for (int i = 1; i < numOfCust + 1; i++) {
            Supplier<Double> supplier = arrival.get(i - 1).second();
            double arrivalTime = arrival.get(i - 1).first();
            Customer cust = new Customer(i, arrivalTime, supplier);
            pq = pq.add(new Arrive(cust, arrivalTime));
        }
        this.eventPQ = pq;

        this.shop = new Shop(servers, selfChecks, queueSize, restTimeSupplier);
    }

    public String run() {
        Statistic statistic = new Statistic();
        Shop shopState = new Shop(shop);
        String result = "";
        PQ<Event> queue = new PQ<Event>(eventPQ); // all Arrive events

        while (!queue.isEmpty()) {
            Pair<Event, PQ<Event>> pollQueue = queue.poll();
            Event currentEvent = pollQueue.first();
            Double currentEventTime = currentEvent.getEventTime();
            queue = pollQueue.second(); // remaining events

            if (currentEvent.getIdentifier().equals("Serve")) {
                Server currentEventServer = currentEvent.getServer();
                Server shopStateServer = shopState.findServerByID(currentEventServer.getServerID());
                Customer currentEventCustomer = currentEvent.getCustomer();
                if (shopStateServer.isHuman() && shopStateServer
                    .getWaitingCustomersList().size() > 0) {
                    Pair<Server,Shop> tempPair = shopState.removeServerWait(shopStateServer);
                    Server tempServer = tempPair.first();
                    Shop tempShop = tempPair.second();
                    Pair<Server,Shop> updatedPair = tempShop
                        .assignServer(tempServer, currentEventCustomer,
                        currentEventTime + currentEventCustomer.getCustomerServiceTime());
                    shopState = updatedPair.second();
                } else if (shopStateServer.isSelfCheckout() &&
                    shopStateServer.getWaitingCustomersList().size() > 0) {
                    Pair<Server,Shop> tempPair = shopState
                        .removeSelfCheckoutWait(currentEventServer);
                    Server tempServer = tempPair.first();
                    Shop tempShop = tempPair.second();
                    Pair<Server,Shop> updatedPair = tempShop
                        .assignServer(tempServer, currentEventCustomer,
                        currentEventTime + currentEventCustomer.getCustomerServiceTime());
                    Server updatedServer = updatedPair.first();
                    ImList<Optional<Customer>> updatedQueue = updatedServer
                        .getWaitingCustomersList();
                    shopState = updatedPair.second().updateSelfCheckouts(updatedQueue);
                } else { // if there is no queue, serve the current customer
                    Pair<Server,Shop> updatedPair = shopState
                        .assignServer(shopStateServer, currentEventCustomer,
                        currentEventTime + currentEventCustomer.getCustomerServiceTime());
                    shopState = updatedPair.second();
                }

                statistic = statistic.addWaitingTime(currentEvent.getEventTime() - currentEvent
                    .getCustomer().getCustomerArrivalTime());

            } else if (currentEvent.getIdentifier().equals("Wait")) {
                Server currentEventServer = currentEvent.getServer();
                Server shopStateServer = shopState.findServerByID(currentEventServer.getServerID());
                Customer currentEventCustomer = currentEvent.getCustomer();
                if (shopStateServer.isSelfCheckout()) {
                    Pair<Server,Shop> updatedPair = shopState
                        .assignQueue(shopStateServer, currentEventCustomer);
                    Server updatedServer = updatedPair.first();
                    ImList<Optional<Customer>> updatedQueue = updatedServer
                        .getWaitingCustomersList();
                    shopState = updatedPair.second().updateSelfCheckouts(updatedQueue);
                } else {
                    Pair<Server,Shop> updatedPair = shopState
                        .assignQueue(shopStateServer, currentEventCustomer);
                    shopState = updatedPair.second();
                }

            } else if (currentEvent.getIdentifier().equals("Done")) {
                Server currentEventServer = currentEvent.getServer();
                Server shopStateServer = shopState.findServerByID(currentEventServer.getServerID());
                Pair<Server,Shop> updatedPair = shopState.removeServerServe(shopStateServer);
                Server updatedServer = updatedPair.first();
                shopState = updatedPair.second();
                if (updatedServer.isHuman()) {
                    double restTime = updatedServer.getRestTime();

                    if (restTime > 0) {
                        updatedServer = updatedServer.rest(restTime);
                        Rest newRest = new Rest(currentEvent.getCustomer(), 
                            currentEvent.getEventTime(), updatedServer);
                        queue = queue.add(newRest);
                    } else {
                        if (updatedServer.getWaitingCustomersList().size() > 0) {
                            Serve newServe = new Serve(updatedServer
                                .getWaitingCustomersList().get(0)
                                .orElse(new Customer(0, 0)),
                                currentEvent.getEventTime(), updatedServer);
                            queue = queue.add(newServe);
                        }
                    }
                } else {
                    if (updatedServer.getWaitingCustomersList().size() > 0) {
                        Serve newServe = new Serve(updatedServer.getWaitingCustomersList().get(0)
                            .orElse(new Customer(0, 0)),
                            currentEvent.getEventTime(), updatedServer);
                        queue = queue.add(newServe);
                    }
                }

                statistic = statistic.addCustomerServed();

            } else if (currentEvent.getIdentifier().equals("Rest")) {
                Server currentEventServer = currentEvent.getServer();
                Server shopStateServer = shopState.findServerByID(currentEventServer.getServerID());
                Server updatedServer = shopStateServer
                    .rest(currentEventServer.getNextAvailableTime() - currentEventTime);
                shopState = shopState.updateServer(updatedServer);
            } else if (currentEvent.getIdentifier().equals("Remove")) {
                Server currentEventServer = currentEvent.getServer();
                Server shopStateServer = shopState.findServerByID(currentEventServer.getServerID());
                Pair<Server,Shop> updatedPair = shopState.removeServerRest(shopStateServer);
                shopState = updatedPair.second();
            } else if (currentEvent.getIdentifier().equals("Leave")) {
                statistic = statistic.addCustomerLeft();
            }

            if (!currentEvent.getIdentifier().equals("Rest") 
                && !currentEvent.getIdentifier().equals("Remove")) {
                result += currentEvent.toString() + "\n";
            }

            Pair<Optional<Event>,Shop> executeEvent = currentEvent.execute(shopState);

            if (!executeEvent.first().equals(Optional.<Event>empty())) {
                queue = queue.add(executeEvent.first()
                    .orElse(new EventStub(new Customer(0, 0), 0)));
            }
        }

        result += statistic.toString();

        return result;
    }


    @Override
    public String toString() {
        return String.format("Queue: %s; Shop: %s", eventPQ.toString(), shop.toString());
    }
}
