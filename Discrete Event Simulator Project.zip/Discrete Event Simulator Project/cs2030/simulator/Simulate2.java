package cs2030.simulator;

import java.util.List;

import cs2030.util.PQ;
import cs2030.util.Pair;

public class Simulate2 {
    private final PQ<Event> eventPQ;
    private final Shop shop;

    public Simulate2(int servers, List<Double> arrival) {
        PQ<Event> pq = new PQ<Event>(new EventComparator());
        int numOfCust = arrival.size();
        for (int i = 1; i < numOfCust + 1; i++) {
            Customer cust = new Customer(i, arrival.get(i - 1));
            pq = pq.add(new EventStub(cust, arrival.get(i - 1)));
        }
        this.eventPQ = pq;

        this.shop = new Shop(servers, 1);
    }

    public String run() {
        String result = "";
        PQ<Event> tempPQ = new PQ<Event>(eventPQ);

        while (!tempPQ.isEmpty()) {
            Pair<Event, PQ<Event>> pair = tempPQ.poll();
            result += pair.first().toString() + "\n";
            tempPQ = pair.second();
        }
        result += "-- End of Simulation --";

        return result;
    }

    @Override
    public String toString() {
        return String.format("Queue: %s; Shop: %s", eventPQ.toString(), shop.toString());
    }
}
