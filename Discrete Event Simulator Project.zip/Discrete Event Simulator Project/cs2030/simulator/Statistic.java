package cs2030.simulator;

public class Statistic {
    private final double waitingTime;
    private final int customerServed;
    private final int customerLeft;

    public Statistic() {
        this.waitingTime = 0;
        this.customerServed = 0;
        this.customerLeft = 0;
    }
    
    public Statistic(double waitingTime, int customerServed, int customerLeft) {
        this.waitingTime = waitingTime;
        this.customerServed = customerServed;
        this.customerLeft = customerLeft;
    }

    public double getWaitingTime() {
        return waitingTime;
    }

    public int getServedCount() {
        return customerServed;
    }

    public int getCustomerLeft() {
        return customerLeft;
    }

    public Statistic addWaitingTime(double time) {
        return new Statistic(getWaitingTime() + time, getServedCount(), getCustomerLeft());
    }

    public Statistic addCustomerServed() {
        return new Statistic(getWaitingTime(), getServedCount() + 1, getCustomerLeft());
    }

    public Statistic addCustomerLeft() {
        return new Statistic(getWaitingTime(), getServedCount(), getCustomerLeft() + 1);
    }

    @Override
    public String toString() {
        return String.format("[%.3f %s %s]",
            getWaitingTime() / getServedCount(), getServedCount(), getCustomerLeft());
    }
    
}
