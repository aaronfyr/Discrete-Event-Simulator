package cs2030.simulator;

import java.util.Optional;

import cs2030.util.Pair;

public class Rest extends Event {
    private final Server server;
        
    public Rest(Customer cust, double eventTime, Server server) {
        super(cust, eventTime, "Rest");
        this.server = server;
    }

    public Server getServer() {
        return server;
    }

    @Override
    public Pair<Optional<Event>,Shop> execute(Shop shop) {
        RemoveRest removeRest = new RemoveRest(getCustomer(),
            getServer().getNextAvailableTime(), getServer());
        return Pair.<Optional<Event>,Shop>of(Optional.<Event>of(removeRest), shop);
    }

}

