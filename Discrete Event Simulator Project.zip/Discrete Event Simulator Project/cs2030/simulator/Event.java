package cs2030.simulator;

import java.util.Optional;

import cs2030.util.ImList;
import cs2030.util.Pair;

public abstract class Event implements Comparable<Event> {
    private final Customer cust;
    private final double eventTime;
    private final String identifier;

    public Event(Customer cust, double eventTime, String identifier) {
        this.cust = cust;
        this.eventTime = eventTime;
        this.identifier = identifier;
    }

    public Customer getCustomer() {
        return cust;
    }

    public double getEventTime() {
        return eventTime;
    }

    public String getIdentifier() {
        return identifier;
    }

    @Override
    public int compareTo(Event otherEvent) {
        ImList<String> eventTypes = ImList.<String>of()
            .add("Done")
            .add("Rest")
            .add("Remove")
            .add("Serve")
            .add("Wait")
            .add("Arrive")
            .add("Leave")
            .add("Stub");

        int compareTime = Double.compare(getEventTime(), otherEvent.getEventTime());
        if (compareTime != 0) {
            return compareTime;
        } else {
            int thisType = eventTypes.indexOf(getIdentifier());
            int otherType = eventTypes.indexOf(otherEvent.getIdentifier());
            return thisType - otherType;
        }
    }

    @Override
    public String toString() {
        return String.format("%.3f", eventTime);
    }
    
    public abstract Server getServer();

    public abstract Pair<Optional<Event>, Shop> execute(Shop shop);

}