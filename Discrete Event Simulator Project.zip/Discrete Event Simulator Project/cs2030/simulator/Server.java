package cs2030.simulator;

import java.util.Optional;
import java.util.function.Supplier;

import cs2030.util.ImList;

public class Server {
    private final int id;
    private final Optional<Customer> serving;
    private final ImList<Optional<Customer>> waiting;
    private final double nextAvailableTime;
    private final int queueSize;
    private final Supplier<Double> restTimeSupplier;
    private final boolean isResting;
    private final String identifier;

    public Server(int id) {
        this.id = id;
        this.serving = Optional.<Customer>empty();
        this.waiting = ImList.<Optional<Customer>>of();
        this.nextAvailableTime = 0;
        this.queueSize = 1;
        this.restTimeSupplier = () -> 0.0;
        this.isResting = false;
        this.identifier = "Human";
    }

    public Server(int id, String identifier) {
        this.id = id;
        this.serving = Optional.<Customer>empty();
        this.waiting = ImList.<Optional<Customer>>of();
        this.nextAvailableTime = 0;
        this.queueSize = 1;
        this.restTimeSupplier = () -> 0.0;
        this.isResting = false;
        this.identifier = identifier;
    }

    public Server(int id, int queueSize, String identifier) {
        this.id = id;
        this.serving = Optional.<Customer>empty();
        this.waiting = ImList.<Optional<Customer>>of();
        this.nextAvailableTime = 0;
        this.queueSize = queueSize;
        this.restTimeSupplier = () -> 0.0;
        this.isResting = false;
        this.identifier = identifier;
    }

    public Server(int id, int queueSize, Supplier<Double> supplier, String identifier) {
        this.id = id;
        this.serving = Optional.<Customer>empty();
        this.waiting = ImList.<Optional<Customer>>of();
        this.nextAvailableTime = 0;
        this.queueSize = queueSize;
        this.restTimeSupplier = supplier;
        this.isResting = false;
        this.identifier = identifier;
    }

    public Server(int id, Optional<Customer> servingCustomer,
            ImList<Optional<Customer>> waitingCustomers, double nextAvailableTime,
            int queueSize, String identifier) {
        this.id = id;
        this.serving = servingCustomer;
        this.waiting = waitingCustomers;
        this.nextAvailableTime = nextAvailableTime;
        this.queueSize = queueSize;
        this.restTimeSupplier = () -> 0.0;
        this.isResting = false;
        this.identifier = identifier;
    }

    public Server(int id, Optional<Customer> servingCustomer, 
            ImList<Optional<Customer>> waitingCustomers, double nextAvailableTime,
            int queueSize, Supplier<Double> supplier, boolean restStatus, String identifier) {
        this.id = id;
        this.serving = servingCustomer;
        this.waiting = waitingCustomers;
        this.nextAvailableTime = nextAvailableTime;
        this.queueSize = queueSize;
        this.restTimeSupplier = supplier;
        this.isResting = restStatus;
        this.identifier = identifier;
    }

    public Server(Server server) {
        this.id = server.getServerID();
        this.serving = server.getServingCust();
        this.waiting = server.getWaitingCustomersList();
        this.nextAvailableTime = server.getNextAvailableTime();
        this.queueSize = server.getQueueSize();
        this.restTimeSupplier = server.getRestSupplier();
        this.isResting = server.getRestStatus();
        this.identifier = server.getServerIdentifier();
    }

    public int getServerID() { // GETTER
        return id;
    }

    public Optional<Customer> getServingCust() { // GETTER
        return serving;
    }

    public ImList<Optional<Customer>> getWaitingCustomersList() { // GETTER
        return waiting;
    }

    public double getNextAvailableTime() { // GETTER
        return nextAvailableTime;
    }

    public int getQueueSize() { // GETTER
        return queueSize;
    }

    public Supplier<Double> getRestSupplier() { // GETTER
        return restTimeSupplier;
    }

    public boolean getRestStatus() {
        return isResting;
    }

    public double getRestTime() {
        return restTimeSupplier.get();
    }

    public String getServerIdentifier() {
        return identifier;
    }

    public int queryCustomerQueueNumber(Customer c) { // FIND INDEX OF CUSTOMER
        Optional<Customer> customer = Optional.<Customer>of(c);
        return getWaitingCustomersList().indexOf(customer);
    }

    public boolean isHuman() {
        return this.getServerIdentifier().equals("Human");
    }

    public boolean isSelfCheckout() {
        return this.getServerIdentifier().equals("Self");
    }
    
    public boolean canServe() { // CHECK IF SERVER CAN SERVE
        return serving.equals(Optional.empty());
    }

    public boolean canWait() { // CHECK IF SERVER CAN WAIT
        return waiting.size() < queueSize;
    }

    public Server humanServe(Customer c, double eventTime) {
        return new Server(getServerID(), Optional.<Customer>of(c), getWaitingCustomersList(),
            eventTime, getQueueSize(), getRestSupplier(), getRestStatus(), "Human");
    }

    public Server selfServe(Customer c, double eventTime) {
        return new Server(getServerID(), Optional.<Customer>of(c), getWaitingCustomersList(),
            eventTime, getQueueSize(), getRestSupplier(), getRestStatus(), "Self");
    }

    public Server humanWait(Customer c) {
        return new Server(getServerID(), getServingCust(), 
            getWaitingCustomersList().add(Optional.<Customer>of(c)), getNextAvailableTime(),
            getQueueSize(), getRestSupplier(), getRestStatus(), "Human");
    }

    public Server selfWait(Customer c) {
        return new Server(getServerID(), getServingCust(),
            getWaitingCustomersList().add(Optional.<Customer>of(c)),
            getNextAvailableTime(), getQueueSize(), getRestSupplier(),
            getRestStatus(), "Self");
    }

    public Server rest(double restTime) {
        return new Server(getServerID(), getServingCust(),
            getWaitingCustomersList(), getNextAvailableTime() + restTime,
            getQueueSize(), getRestSupplier(), true, "Human");
    }

    public Server updateWait(Customer c, int index) {
        return new Server(getServerID(), getServingCust(),
            getWaitingCustomersList().set(index, Optional.<Customer>of(c)), getNextAvailableTime(), 
            getQueueSize(), getRestSupplier(), getRestStatus(), "Human");
    }

    public Server humanClearServe() {
        return new Server(getServerID(), Optional.<Customer>empty(), getWaitingCustomersList(),
            getNextAvailableTime(), getQueueSize(), getRestSupplier(),
            getRestStatus(), "Human");
    }

    public Server selfClearServe() {
        return new Server(getServerID(), Optional.<Customer>empty(), getWaitingCustomersList(),
            getNextAvailableTime(), getQueueSize(), getRestSupplier(),
            getRestStatus(), "Self");
    }

    public Server humanClearWait() {
        return new Server(getServerID(), getServingCust(), 
            getWaitingCustomersList().remove(0).second(), getNextAvailableTime(),
            getQueueSize(), getRestSupplier(), getRestStatus(), "Human");
    }

    public Server selfClearWait() {
        return new Server(getServerID(), getServingCust(), 
            getWaitingCustomersList().remove(0).second(), getNextAvailableTime(),
            getQueueSize(), getRestSupplier(), getRestStatus(), "Self");
    }

    public Server clearRest() {
        return new Server(getServerID(), getServingCust(), getWaitingCustomersList(),
            getNextAvailableTime(), getQueueSize(), getRestSupplier(), false, "Human");
    }

    public Server selfSetWait(ImList<Optional<Customer>> queue) {
        return new Server(getServerID(), getServingCust(), queue,
            getNextAvailableTime(), getQueueSize(), "Self");
    }

    @Override
    public String toString() {
        return String.valueOf(getServerID());
    }
}
