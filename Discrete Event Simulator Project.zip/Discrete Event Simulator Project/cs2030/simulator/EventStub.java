package cs2030.simulator;

import java.util.Optional;

import cs2030.util.Pair;

public class EventStub extends Event {

    public EventStub(Customer cust, double eventTime) {
        super(cust, eventTime, "EventStub");
    }

    @Override
    public Server getServer() {
        return new Server(0, "Human");
    }

    @Override
    public Pair<Optional<Event>, Shop> execute(Shop shop) {
        return Pair.<Optional<Event>,Shop>of(Optional.<Event>empty(), shop);
    }


}
