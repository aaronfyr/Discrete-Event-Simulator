package cs2030.simulator;

import java.util.function.Supplier;

import cs2030.util.Lazy;

public class Customer {
    private final int id;
    private final double arrivalTime;
    private final Lazy<Double> serviceTimeSupplier;

    public Customer(int id, double arrivalTime) {
        this.id = id;
        this.arrivalTime = arrivalTime;
        this.serviceTimeSupplier = new Lazy<Double>(() -> 1.0);
    }

    public Customer(int id, double arrivalTime, Supplier<Double> supplier) {
        this.id = id;
        this.arrivalTime = arrivalTime;
        this.serviceTimeSupplier = Lazy.<Double>of(supplier);
    }

    public Customer(Customer customer) {
        this.id = customer.getCustomerID();
        this.arrivalTime = getCustomerArrivalTime();
        this.serviceTimeSupplier = customer.getServiceTimeSupplier();
    }

    public int getCustomerID() {
        return id;
    }

    public double getCustomerArrivalTime() {
        return arrivalTime;
    }
    
    public Lazy<Double> getServiceTimeSupplier() {
        return serviceTimeSupplier;
    }

    public double getCustomerServiceTime() {
        return serviceTimeSupplier.get();
    }

    @Override
    public String toString() {
        return String.valueOf(id);
    }
}
