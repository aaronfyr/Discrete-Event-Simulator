package cs2030.simulator;

import java.util.Optional;

import cs2030.util.Pair;

public class RemoveRest extends Event {
    private final Server server;
        
    public RemoveRest(Customer cust, double eventTime, Server server) {
        super(cust, eventTime, "Remove");
        this.server = server;
    }

    public Server getServer() {
        return server;
    }

    @Override
    public Pair<Optional<Event>,Shop> execute(Shop shop) {
        // Pair<Server,Shop> updatedPair = shop.removeServerRest(getServer());
        // Server updatedServer = updatedPair.first();
        // Shop updatedShop = updatedPair.second();
        Server shopStateServer = shop.findServerByID(getServer().getServerID());
        if (shopStateServer.getWaitingCustomersList().size() > 0) {
            Serve newServe = new Serve(shopStateServer.getWaitingCustomersList().get(0)
                .orElse(new Customer(0, 0)), getServer().getNextAvailableTime(), shopStateServer);
            return Pair.<Optional<Event>,Shop>of(Optional.<Event>of(newServe), shop);
        } else {
            return Pair.<Optional<Event>,Shop>of(Optional.<Event>empty(), shop);
        }
    }

    // @Override
    // public String toString() {
    //     return String.format("%s Resting done @ %.3f", 
    //     getServer().getServerID(), getServer().getNextAvailableTime());
    // }
}

