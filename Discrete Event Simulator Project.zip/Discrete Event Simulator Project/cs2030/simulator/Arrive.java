package cs2030.simulator;

import java.util.Optional;

import cs2030.util.Pair;

public class Arrive extends Event {

    public Arrive(Customer cust, double eventTime) {
        super(cust, eventTime, "Arrive");
    }

    @Override
    public Server getServer() {
        return new Server(0, "Human");
    }

    @Override
    public Pair<Optional<Event>, Shop> execute(Shop shop) {
        if (shop.isThereServer()) { // Serve
            Server chosenServerToServe = shop.findServer();
            Serve newServe = new Serve(getCustomer(), 
                getEventTime(), chosenServerToServe); // call a serve at current event time
            return Pair.<Optional<Event>,Shop>of(Optional.<Event>of(newServe), shop);
        } else if (!shop.isThereServer() && shop.canQueue()) { // Wait
            Server chosenServerToWait = shop.findQueue();
            Wait newWait = new Wait(getCustomer(), getEventTime(), 
                chosenServerToWait); // call a wait at current event time
            return Pair.<Optional<Event>,Shop>of(Optional.<Event>of(newWait), shop);
        } else { // Leave
            Leave newLeave = new Leave(getCustomer(), getEventTime());
            return Pair.<Optional<Event>,Shop>of(Optional.<Event>of(newLeave), shop);
        }
    }

    @Override
    public String toString() {
        return String.format("%.3f %s arrives", getCustomer()
        .getCustomerArrivalTime(), getCustomer().getCustomerID());
    }
}
